# Start — custom new tab extension

## Load it
1. Open `chrome://extensions`, switch on **Developer mode**.
2. **Load unpacked** → pick this folder.
3. After any edit: click the reload icon on the extension card, then open a new tab.

## Customize
- `js/config.js` — name, wallpapers, rotation, clock, accent colour, shortcuts, which tools show, apps grid, assistant URL.
- `css/style.css` — the `:root` block at the top holds colours, radius and font.
- `_locales/en/messages.json` — the name/description Chrome shows on the extensions page.
- `icons/` — placeholder icons (16/32/48/128). Replace with your own, keep the file names.
- `img/` — add wallpapers, then list them in `config.js`.

## Widgets
- Bottom-left: weather, month calendar, analog clock. Toggle each in `widgets` in `config.js`; `widgets.style` is `"light"` or `"dark"`.
- Weather: set `weather.city` and `weather.units`. The forecast is cached for 20 minutes.
- Control center (tools menu, first button): network status, focus timer, next/pause wallpaper, light/dark widgets, Display (wallpaper brightness) and Glass sliders, plus shortcuts to calculator, stopwatch, notes and to-do. These can't change real device settings; a browser extension has no access to Wi-Fi, Bluetooth, system volume/brightness or other apps' media.

## Notes
- The only network calls are the weather lookups to Open-Meteo (the city name, then its coordinates). Turn off `widgets.weather` and the extension makes none. Favicons come from Chrome's local cache (`favicon` permission); the only other permission is `search`.
- Weather data: Open-Meteo.com (free for non-commercial use, attribution requested).
- Font: Manrope (SIL OFL, see `fonts/OFL-Manrope.txt`).
