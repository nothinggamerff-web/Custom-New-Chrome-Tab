// Small DOM helpers, inline icons and the single-panel manager.
// Everything is built with createElement/textContent — no user text goes through innerHTML.

const ICON_PATHS = {
  search:     '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  grid:       '<rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/>',
  compass:    '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
  sparkle:    '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16v4M17 18h4"/>',
  calendar:   '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
  calculator: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
  note:       '<path d="M5 4h14v11l-5 5H5z"/><path d="M14 20v-5h5"/>',
  todo:       '<path d="m5 7 2 2 3-4M5 16l2 2 3-4M13 8h6M13 17h6"/>',
  timer:      '<circle cx="12" cy="13" r="7"/><path d="M12 9v4l2.5 2M9.5 3h5"/>',
  plus:       '<path d="M12 5v14M5 12h14"/>',
  close:      '<path d="M6 6l12 12M18 6 6 18"/>',
  send:       '<path d="M5 12h14M13 6l6 6-6 6"/>',
  chevL:      '<path d="m14 6-6 6 6 6"/>',
  wifi:       '<path d="M4.5 10a11 11 0 0 1 15 0M7.5 13.2a6.7 6.7 0 0 1 9 0"/><circle cx="12" cy="17.2" r="1.2" fill="currentColor" stroke="none"/>',
  wifiOff:    '<path d="M4.5 10a11 11 0 0 1 4-2.4M19.5 10a11 11 0 0 0-3.5-2.2M7.5 13.2a6.7 6.7 0 0 1 3-1.6M16.5 13.2a6.7 6.7 0 0 0-1.3-1M4 4l16 16"/><circle cx="12" cy="17.2" r="1.2" fill="currentColor" stroke="none"/>',
  sliders:    '<path d="M5 8h9M18 8h1M5 16h1M10 16h9"/><circle cx="16" cy="8" r="2"/><circle cx="8" cy="16" r="2"/>',
  play:       '<path d="M8 5.5v13l11-6.5z" fill="currentColor"/>',
  pause:      '<rect x="7" y="5.5" width="3.6" height="13" rx="1" fill="currentColor" stroke="none"/><rect x="13.4" y="5.5" width="3.6" height="13" rx="1" fill="currentColor" stroke="none"/>',
  reset:      '<path d="M4 12a8 8 0 1 1 2.6 5.9M4 5.5V12h6.5"/>',
  refresh:    '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v4.5H15"/>',
  sun:        '<circle cx="12" cy="12" r="3.8"/><path d="M12 3.5v2M12 18.5v2M3.5 12h2M18.5 12h2M6 6l1.4 1.4M16.6 16.6 18 18M18 6l-1.4 1.4M7.4 16.6 6 18"/>',
  moon:       '<path d="M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10z"/>',
  swatch:     '<circle cx="12" cy="12" r="8"/><path d="M12 4v16" /><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/>',
  chevR:      '<path d="m10 6 6 6-6 6"/>',
};

function icon(name) {
  const s = document.createElement("span");
  s.className = "icon";
  s.setAttribute("aria-hidden", "true");
  s.innerHTML =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" ' +
    'stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">' +
    (ICON_PATHS[name] || "") + "</svg>";
  return s;
}

function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === "class") n.className = v;
    else if (k === "text") n.textContent = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) if (kid != null) n.append(kid);
  return n;
}

// Chrome's local favicon cache (needs the "favicon" permission). No third-party requests.
function faviconURL(pageUrl, size = 64) {
  const u = new URL(chrome.runtime.getURL("/_favicon/"));
  u.searchParams.set("pageUrl", pageUrl);
  u.searchParams.set("size", String(size));
  return u.toString();
}

// <img> that falls back to the first letter of the name if no favicon is cached.
function siteIcon(url, name) {
  const wrap = el("span", { class: "site-icon" });
  const img = el("img", { alt: "", src: faviconURL(url), draggable: "false" });
  img.addEventListener("error", () => {
    img.remove();
    wrap.textContent = (name || "?").trim().charAt(0).toUpperCase() || "?";
  });
  wrap.append(img);
  return wrap;
}

// Accepts "example.com" or full URLs; only http(s) is allowed (blocks javascript:, data:, etc.)
function normalizeUrl(input) {
  let s = (input || "").trim();
  if (!s) return null;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(s)) s = "https://" + s;
  try {
    const u = new URL(s);
    return u.protocol === "http:" || u.protocol === "https:" ? u.toString() : null;
  } catch {
    return null;
  }
}

function store(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}
function save(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

// ---- One floating panel at a time -------------------------------------------------
const Panels = (() => {
  let current = null; // { id, node, onClose }

  function close() {
    if (!current) return;
    try { current.onClose && current.onClose(); } catch {}
    current.node.remove();
    current = null;
  }

  function toggle(id, title, build, opts = {}) {
    if (current && current.id === id) return close();
    close();
    const ctx = { onClose: null, close };
    const body = el("div", { class: "panel-body" });
    const node = el(
      "section",
      { class: "panel" + (opts.bare ? " bare" : ""), id: "panel-" + id, "aria-label": title },
      el("header", { class: "panel-head" },
        el("h2", { text: title }),
        el("button", { type: "button", class: "icon-btn", "aria-label": "Close", onclick: close }, icon("close"))
      ),
      body
    );
    document.body.append(node);
    build(body, ctx);
    current = { id, node, onClose: ctx.onClose };
    const first = node.querySelector("input, button.primary");
    if (first) first.focus();
  }

  document.addEventListener("pointerdown", (e) => {
    if (!current) return;
    if (current.node.contains(e.target)) return;
    if (e.target.closest("#tools, .shortcut-add, .note")) return;
    close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") close();
  });

  return { toggle, close };
})();
