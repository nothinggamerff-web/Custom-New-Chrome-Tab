// Everything you're likely to want to tweak lives in this file.
// After editing, reload the extension at chrome://extensions and open a new tab.

const CONFIG = {
  // Used as the page title. (The name in the Chrome toolbar/extensions page
  // comes from _locales/en/messages.json.)
  name: "Start",

  // BCP 47 tag like "en-GB" or "de-DE" for dates/calendar. null = browser default.
  locale: null,

  clock: {
    hour12: true,        // click the clock to flip this; your choice is remembered
    showSeconds: false,
  },

  search: {
    placeholder: "Search the web",
  },

  theme: {
    accent: "#7aa7ff",   // focus rings, buttons, "today" highlight
    idleOpacity: 0.85,    // shortcuts/tools fade to this until hovered (1 = never fade)
  },

  wallpapers: {
    // Paths are relative to index.html. Drop files in /img and list them here.
    images: [
      "img/wall-1.webp",
      "img/wall-2.webp",
      "img/wall-3.webp",
      "img/wall-4.webp",
      "img/wall-5.webp",
      "img/wall-6.webp",
      "img/wall-7.webp",
    ],
    rotateSeconds: 30,   // 0 = pick one per tab and stay on it
    shade: 0.55,         // 0–1, darkens top and bottom edges so text stays readable
  },

  // Glass widgets along the bottom-left (weather, month calendar, analog clock).
  widgets: {
    style: "light",      // "light" = frosted white glass, "dark" = smoked glass
    weather: true,
    calendar: true,
    clock: true,
  },

  // Weather comes from Open-Meteo (free, no account). Only the city name and
  // its coordinates are sent. Set widgets.weather to false to switch it off.
  weather: {
    city: "Seoul",
    units: "celsius",    // or "fahrenheit"
  },

  // Left-hand shortcut tiles. You can also add/remove tiles from the page itself;
  // those changes are saved in the browser and layered on top of this list.
  shortcuts: [
    { name: "Gmail",   url: "https://mail.google.com/" },
    { name: "YouTube", url: "https://www.youtube.com/" },
    { name: "GitHub",  url: "https://github.com/" },
    { name: "Maps",    url: "https://maps.google.com/" },
    { name: "Drive",   url: "https://drive.google.com/" },
  ],

  // Tools menu (top right). Set any to false to hide it.
  tools: {
    control: true,
    apps: true,
    assistant: true,
    calendar: true,
    calculator: true,
    notes: true,
    todo: true,
    stopwatch: true,
  },

  // Calendar: 0 = Sunday first, 1 = Monday first.
  weekStartsOn: 0,

  // The "Ask" box opens this URL in a new tab with your question appended.
  assistant: {
    name: "ChatGPT",
    url: "https://chatgpt.com/?q=",
  },

  // Grid shown by the Apps tool.
  apps: [
    { name: "Gmail",     url: "https://mail.google.com/" },
    { name: "Drive",     url: "https://drive.google.com/" },
    { name: "Docs",      url: "https://docs.google.com/" },
    { name: "Sheets",    url: "https://sheets.google.com/" },
    { name: "Slides",    url: "https://slides.google.com/" },
    { name: "Calendar",  url: "https://calendar.google.com/" },
    { name: "Translate", url: "https://translate.google.com/" },
    { name: "Maps",      url: "https://maps.google.com/" },
    { name: "YouTube",   url: "https://www.youtube.com/" },
    { name: "News",      url: "https://news.google.com/" },
    { name: "Keep",      url: "https://keep.google.com/" },
    { name: "Photos",    url: "https://photos.google.com/" },
    { name: "Forms",     url: "https://forms.google.com/" },
    { name: "Contacts",  url: "https://contacts.google.com/" },
  ],

  // Sticky note colours (soft pastels; text on notes is dark).
  noteColors: ["#f6e7a8", "#f4c7c3", "#c9e6c0", "#c3dcf2", "#e0cdf0"],
};
