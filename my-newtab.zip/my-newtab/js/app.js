(function () {
  const $ = (s) => document.querySelector(s);
  const root = document.documentElement;

  // ---- Theme + static text from config -------------------------------------------
  document.title = CONFIG.name || "New Tab";
  root.style.setProperty("--accent", CONFIG.theme.accent);
  root.style.setProperty("--idle-opacity", String(CONFIG.theme.idleOpacity));
  root.style.setProperty("--shade", String(CONFIG.wallpapers.shade));
  $("#searchInput").placeholder = CONFIG.search.placeholder;
  $("#searchSubmit").append(icon("search"));
  $("#toolsToggle").append(icon("grid"));

  // ---- Wallpaper: crossfade between two layers -----------------------------------
  const layers = [$("#bgA"), $("#bgB")];
  const images = CONFIG.wallpapers.images || [];
  let active = -1;
  let last = -1;
  let paused = store("wall.paused", false);

  function showWallpaper() {
    if (!images.length) return;
    let i;
    do { i = Math.floor(Math.random() * images.length); } while (images.length > 1 && i === last);
    last = i;
    const src = images[i];
    const probe = new Image();
    probe.onload = () => {
      const next = layers[active === 0 ? 1 : 0];
      next.style.backgroundImage = `url("${src}")`;
      next.classList.add("on");
      if (active !== -1) layers[active].classList.remove("on");
      active = active === 0 ? 1 : 0;
    };
    probe.src = src; // on error nothing changes; the current wallpaper stays
  }
  showWallpaper();
  if (CONFIG.wallpapers.rotateSeconds > 0 && images.length > 1) {
    setInterval(() => { if (!document.hidden && !paused) showWallpaper(); }, CONFIG.wallpapers.rotateSeconds * 1000);
  }
  // Used by the Control center
  window.Wallpaper = {
    next: showWallpaper,
    get paused() { return paused; },
    togglePause() { paused = !paused; save("wall.paused", paused); return paused; },
  };

  // ---- Clock ---------------------------------------------------------------------
  let hour12 = store("clock.hour12", CONFIG.clock.hour12);
  const timeEl = $("#time");
  const todayEl = $("#today");
  const locale = CONFIG.locale || undefined;

  function tick() {
    const d = new Date();
    const t = d.toLocaleTimeString(locale, {
      hour: "numeric",
      minute: "2-digit",
      second: CONFIG.clock.showSeconds ? "2-digit" : undefined,
      hour12,
    });
    if (timeEl.textContent !== t) timeEl.textContent = t;
    const day = d.toLocaleDateString(locale, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
    if (todayEl.textContent !== day) todayEl.textContent = day;
  }
  function flipClock() { hour12 = !hour12; save("clock.hour12", hour12); tick(); document.dispatchEvent(new Event("clockformat")); }
  timeEl.addEventListener("click", flipClock);
  timeEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); flipClock(); }
  });
  tick();
  setInterval(tick, 1000);

  // ---- Search --------------------------------------------------------------------
  $("#searchBar").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = $("#searchInput").value.trim();
    if (!q) return;
    // Looks like a web address? Go there. Otherwise use the browser's default search engine.
    if (/^https?:\/\/\S+$/i.test(q)) { window.location.href = q; return; }
    chrome.search.query({ text: q, disposition: "CURRENT_TAB" });
  });

  // ---- Shortcuts -----------------------------------------------------------------
  // Saved state: user-added tiles, plus the URLs of built-in tiles the user removed.
  let saved = store("shortcuts.v2", { added: [], hidden: [] });
  if (!Array.isArray(saved.added)) saved.added = [];
  if (!Array.isArray(saved.hidden)) saved.hidden = [];
  const shortcutsEl = $("#shortcuts");

  function allShortcuts() {
    const base = (CONFIG.shortcuts || []).filter((s) => !saved.hidden.includes(s.url));
    return [...base, ...saved.added];
  }

  function removeShortcut(url) {
    if ((CONFIG.shortcuts || []).some((s) => s.url === url)) {
      if (!saved.hidden.includes(url)) saved.hidden.push(url);
    } else {
      saved.added = saved.added.filter((s) => s.url !== url);
    }
    save("shortcuts.v2", saved);
    renderShortcuts();
  }

  function openAddShortcut() {
    Panels.toggle("add-shortcut", "Add shortcut", (body) => {
      const name = el("input", { type: "text", placeholder: "Name", maxlength: "20", "aria-label": "Name" });
      const url = el("input", { type: "text", placeholder: "Address, e.g. example.com", "aria-label": "Address" });
      const msg = el("p", { class: "form-msg", "aria-live": "polite" });
      const add = () => {
        const clean = normalizeUrl(url.value);
        if (!clean) { msg.textContent = "Enter a valid web address."; return; }
        const label = name.value.trim() || new URL(clean).hostname.replace(/^www\./, "");
        saved.added.push({ name: label, url: clean });
        save("shortcuts.v2", saved);
        renderShortcuts();
        Panels.close();
      };
      for (const i of [name, url]) i.addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
      body.append(
        el("div", { class: "stack" }, name, url,
          el("button", { type: "button", class: "text-btn primary", text: "Add", onclick: add }), msg)
      );
    });
  }

  function renderShortcuts() {
    shortcutsEl.replaceChildren();
    for (const s of allShortcuts()) {
      const url = normalizeUrl(s.url);
      if (!url) continue;
      shortcutsEl.append(
        el("div", { class: "shortcut" },
          el("a", { href: url, rel: "noopener noreferrer", title: s.name + " — " + url },
            siteIcon(url, s.name),
            el("span", { class: "label", text: s.name })
          ),
          el("button", { type: "button", class: "shortcut-x", "aria-label": "Remove " + s.name,
            onclick: () => removeShortcut(s.url) }, icon("close"))
        )
      );
    }
    shortcutsEl.append(
      el("div", { class: "shortcut shortcut-add" },
        el("button", { type: "button", class: "add-btn", onclick: openAddShortcut },
          el("span", { class: "site-icon" }, icon("plus")),
          el("span", { class: "label", text: "Add" })
        )
      )
    );
  }
  renderShortcuts();

  // ---- Tools menu ----------------------------------------------------------------
  const menu = $("#toolsMenu");
  for (const t of TOOLS) {
    if (CONFIG.tools[t.id] === false) continue;
    menu.append(
      el("button", { type: "button", class: "rail-btn", role: "menuitem", title: t.label,
        "aria-label": t.label, onclick: t.run }, icon(t.icon))
    );
  }
  Notes.restore();
  Widgets.init();
})();
