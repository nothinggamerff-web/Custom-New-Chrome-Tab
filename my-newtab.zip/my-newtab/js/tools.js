// The tools in the top-right menu. Each exposes an open() that builds into the shared panel.

// ---- Apps launcher ----------------------------------------------------------------
function openApps() {
  Panels.toggle("apps", "Apps", (body) => {
    const grid = el("div", { class: "apps-grid" });
    for (const app of CONFIG.apps) {
      const url = normalizeUrl(app.url);
      if (!url) continue;
      grid.append(
        el("a", { href: url, class: "app-tile", rel: "noopener noreferrer" },
          siteIcon(url, app.name),
          el("span", { text: app.name })
        )
      );
    }
    body.append(grid);
  });
}

// ---- Assistant --------------------------------------------------------------------
function openAssistant() {
  const name = CONFIG.assistant.name;
  Panels.toggle("assistant", "Ask " + name, (body) => {
    const input = el("input", { type: "text", placeholder: "Ask " + name + "…", "aria-label": "Question" });
    const go = () => {
      const q = input.value.trim();
      if (!q) return;
      window.open(CONFIG.assistant.url + encodeURIComponent(q), "_blank", "noopener");
      Panels.close();
    };
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") go(); });
    body.append(
      el("div", { class: "row" }, input,
        el("button", { type: "button", class: "icon-btn primary", "aria-label": "Send", onclick: go }, icon("send")))
    );
  });
}

// ---- Calendar ---------------------------------------------------------------------
function openCalendar() {
  Panels.toggle("calendar", "Calendar", (body) => {
    const locale = CONFIG.locale || undefined;
    const ws = CONFIG.weekStartsOn === 1 ? 1 : 0;
    const today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();

    const title = el("h3", { class: "cal-title" });
    const grid = el("div", { class: "cal-grid" });
    const step = (d) => {
      month += d;
      if (month < 0) { month = 11; year--; }
      if (month > 11) { month = 0; year++; }
      render();
    };

    function render() {
      title.textContent = new Date(year, month, 1).toLocaleString(locale, { month: "long", year: "numeric" });
      grid.replaceChildren();
      for (let i = 0; i < 7; i++) {
        // 2021-08-01 was a Sunday
        const name = new Date(2021, 7, 1 + ((i + ws) % 7)).toLocaleString(locale, { weekday: "short" });
        grid.append(el("div", { class: "cal-dow", text: name }));
      }
      const lead = (new Date(year, month, 1).getDay() - ws + 7) % 7;
      for (let i = 0; i < lead; i++) grid.append(el("div"));
      const days = new Date(year, month + 1, 0).getDate();
      for (let d = 1; d <= days; d++) {
        const isToday = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
        grid.append(el("div", { class: "cal-day" + (isToday ? " today" : ""), text: String(d) }));
      }
    }

    body.append(
      el("div", { class: "cal-nav" },
        el("button", { type: "button", class: "icon-btn", "aria-label": "Previous month", onclick: () => step(-1) }, icon("chevL")),
        title,
        el("button", { type: "button", class: "icon-btn", "aria-label": "Next month", onclick: () => step(1) }, icon("chevR"))
      ),
      grid
    );
    render();
  });
}

// ---- Calculator -------------------------------------------------------------------
function openCalculator() {
  Panels.toggle("calculator", "Calculator", (body) => {
    let display = "0", first = null, op = null, waiting = false;
    const out = el("div", { class: "calc-display", "aria-live": "polite", text: "0" });

    const ops = { "/": (a, b) => a / b, "*": (a, b) => a * b, "+": (a, b) => a + b, "-": (a, b) => a - b };
    const fmt = (n) => String(Number(n.toPrecision(12)));
    const clear = () => { display = "0"; first = null; op = null; waiting = false; };

    function digit(d) {
      if (display === "Error") clear();
      if (waiting) { display = d; waiting = false; }
      else display = display === "0" ? d : display + d;
    }
    function dot() {
      if (display === "Error") clear();
      if (waiting) { display = "0."; waiting = false; return; }
      if (!display.includes(".")) display += ".";
    }
    function operate(next) {
      if (display === "Error") return;
      const v = parseFloat(display);
      if (op && waiting) { op = next === "=" ? null : next; return; }
      if (first === null) first = v;
      else if (op) {
        const r = ops[op](first, v);
        if (!isFinite(r)) { clear(); display = "Error"; return; }
        display = fmt(r);
        first = r;
      }
      waiting = true;
      op = next === "=" ? null : next;
      if (next === "=") first = null;
    }

    const keys = [
      ["C", "clear", "fn"], ["±", "sign", "fn"], ["%", "pct", "fn"], ["÷", "/", "op"],
      ["7"], ["8"], ["9"], ["×", "*", "op"],
      ["4"], ["5"], ["6"], ["−", "-", "op"],
      ["1"], ["2"], ["3"], ["+", "+", "op"],
      ["0", null, "zero"], ["."], ["=", "=", "eq"],
    ];
    const pad = el("div", { class: "calc-keys" });
    for (const [label, action, kind] of keys) {
      pad.append(el("button", { type: "button", class: "calc-key " + (kind || ""), text: label, onclick: () => {
        if (action === "clear") clear();
        else if (action === "sign") { if (display !== "Error") display = fmt(parseFloat(display) * -1); }
        else if (action === "pct") { if (display !== "Error") display = fmt(parseFloat(display) / 100); }
        else if (action) operate(action);
        else if (label === ".") dot();
        else digit(label);
        out.textContent = display;
      } }));
    }
    body.append(out, pad);
  });
}

// ---- To-do ------------------------------------------------------------------------
function openTodo() {
  Panels.toggle("todo", "To-do", (body) => {
    let todos = store("todos", []);
    if (!Array.isArray(todos)) todos = [];
    const list = el("ul", { class: "todo-list" });
    const input = el("input", { type: "text", placeholder: "Add a task", "aria-label": "New task" });

    function render() {
      list.replaceChildren();
      if (!todos.length) list.append(el("li", { class: "empty", text: "Nothing to do." }));
      todos.forEach((t, i) => {
        const check = el("input", { type: "checkbox", "aria-label": "Done" });
        check.checked = !!t.done;
        check.addEventListener("change", () => { todos[i].done = check.checked; save("todos", todos); render(); });
        list.append(
          el("li", { class: t.done ? "done" : "" },
            check,
            el("span", { class: "todo-text", text: String(t.text) }),
            el("button", { type: "button", class: "icon-btn", "aria-label": "Delete task", onclick: () => {
              todos.splice(i, 1); save("todos", todos); render();
            } }, icon("close"))
          )
        );
      });
    }
    const add = () => {
      const v = input.value.trim();
      if (!v) return;
      todos.push({ text: v, done: false });
      input.value = "";
      save("todos", todos);
      render();
    };
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
    body.append(
      el("div", { class: "row" }, input,
        el("button", { type: "button", class: "icon-btn primary", "aria-label": "Add task", onclick: add }, icon("plus"))),
      list
    );
    render();
  });
}

// ---- Stopwatch (keeps running if you close the panel) -----------------------------
const stopwatch = { elapsed: 0, startedAt: 0, running: false };

function openStopwatch() {
  Panels.toggle("stopwatch", "Stopwatch", (body, ctx) => {
    const out = el("div", { class: "sw-display", text: "00:00:00" });
    const startBtn = el("button", { type: "button", class: "text-btn primary" });
    let tick = null;

    const now = () => stopwatch.elapsed + (stopwatch.running ? Date.now() - stopwatch.startedAt : 0);
    const fmt = (ms) => {
      const s = Math.floor(ms / 1000);
      const p = (n) => String(n).padStart(2, "0");
      return `${p(Math.floor(s / 3600))}:${p(Math.floor((s % 3600) / 60))}:${p(s % 60)}`;
    };
    const paint = () => { out.textContent = fmt(now()); startBtn.textContent = stopwatch.running ? "Pause" : "Start"; };

    startBtn.addEventListener("click", () => {
      if (stopwatch.running) { stopwatch.elapsed = now(); stopwatch.running = false; }
      else { stopwatch.startedAt = Date.now(); stopwatch.running = true; }
      paint();
    });
    const reset = el("button", { type: "button", class: "text-btn", text: "Reset", onclick: () => {
      stopwatch.elapsed = 0; stopwatch.running = false; paint();
    } });

    tick = setInterval(paint, 250);
    ctx.onClose = () => clearInterval(tick);
    body.append(out, el("div", { class: "row" }, startBtn, reset));
    paint();
  });
}

// ---- Sticky notes (free-floating, draggable, remembered) --------------------------
const Notes = (() => {
  const KEY = "stickyNotes";
  const colors = () => (CONFIG.noteColors && CONFIG.noteColors.length ? CONFIG.noteColors : ["#f6e7a8"]);
  let saveTimer = null;

  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      const data = [...document.querySelectorAll(".note")].map((n) => ({
        id: n.dataset.id,
        text: n.querySelector("textarea").value,
        color: n.dataset.color,
        left: n.style.left,
        top: n.style.top,
        width: n.style.width,
        height: n.style.height,
      }));
      save(KEY, data);
    }, 150);
  }

  function create(data = {}) {
    const palette = colors();
    const color = data.color || palette[Math.floor(Math.random() * palette.length)];
    const note = el("div", { class: "note" });
    note.dataset.id = data.id || String(Date.now()) + Math.floor(Math.random() * 1000);
    note.dataset.color = color;
    note.style.background = color;
    const maxX = Math.max(40, window.innerWidth - 260);
    const maxY = Math.max(40, window.innerHeight - 260);
    note.style.left = data.left || Math.round(160 + Math.random() * Math.max(0, maxX - 320)) + "px";
    note.style.top = data.top || Math.round(120 + Math.random() * Math.max(0, maxY - 240)) + "px";
    if (data.width) note.style.width = data.width;
    if (data.height) note.style.height = data.height;

    const text = el("textarea", { placeholder: "Write something…", "aria-label": "Note", spellcheck: "false" });
    text.value = data.text || "";
    text.addEventListener("input", persist);

    const head = el("div", { class: "note-head" },
      el("span", { class: "note-grip", "aria-hidden": "true", text: "⋮⋮" }),
      el("button", { type: "button", class: "note-btn", "aria-label": "Delete note", onclick: () => {
        if (!text.value.trim() || confirm("Delete this note?")) { note.remove(); persist(); }
      } }, icon("close"))
    );

    // drag by the header
    head.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      const dx = e.clientX - note.offsetLeft, dy = e.clientY - note.offsetTop;
      head.setPointerCapture(e.pointerId);
      note.style.zIndex = "60";
      const move = (ev) => {
        const x = Math.min(Math.max(0, ev.clientX - dx), window.innerWidth - 60);
        const y = Math.min(Math.max(0, ev.clientY - dy), window.innerHeight - 40);
        note.style.left = x + "px";
        note.style.top = y + "px";
      };
      const up = () => {
        head.removeEventListener("pointermove", move);
        head.removeEventListener("pointerup", up);
        note.style.zIndex = "";
        persist();
      };
      head.addEventListener("pointermove", move);
      head.addEventListener("pointerup", up);
    });
    new ResizeObserver(persist).observe(note);

    note.append(head, text);
    document.body.append(note);
    persist();
    return note;
  }

  function restore() {
    const saved = store(KEY, []);
    if (Array.isArray(saved)) saved.forEach((d) => create(d));
  }

  return { create, restore };
})();

// ---- Registry used by app.js ------------------------------------------------------
const TOOLS = [
  { id: "control",    label: "Control center", icon: "sliders", run: () => openControlCenter() },
  { id: "apps",       label: "Apps",       icon: "compass",    run: openApps },
  { id: "assistant",  label: "Ask " + CONFIG.assistant.name, icon: "sparkle", run: openAssistant },
  { id: "calendar",   label: "Calendar",   icon: "calendar",   run: openCalendar },
  { id: "calculator", label: "Calculator", icon: "calculator", run: openCalculator },
  { id: "notes",      label: "New note",   icon: "note",       run: () => { Panels.close(); Notes.create(); } },
  { id: "todo",       label: "To-do",      icon: "todo",       run: openTodo },
  { id: "stopwatch",  label: "Stopwatch",  icon: "timer",      run: openStopwatch },
];
