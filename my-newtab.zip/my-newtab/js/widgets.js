// Bottom-left glass widgets (weather, calendar, analog clock) and the Control center panel.

// ======================================================================================
// Weather icons (inline SVG, 32x32)
// ======================================================================================
const WX_CLOUD =
  '<path d="M9.5 25a6 6 0 0 1-.9-11.9A8 8 0 0 1 24 12.2 6.4 6.4 0 0 1 23 25z" fill="#f2f5fa" stroke="#9aa8bf" stroke-width="1.1" stroke-linejoin="round"/>';
const WX_SUN_RAYS =
  '<g stroke="#ffb020" stroke-width="2" stroke-linecap="round"><path d="M16 3v3M16 26v3M3 16h3M26 16h3M6.8 6.8l2.1 2.1M23.1 23.1l2.1 2.1M25.2 6.8l-2.1 2.1M8.9 23.1l-2.1 2.1"/></g>';
const WX_ICONS = {
  sun:   '<circle cx="16" cy="16" r="6.2" fill="#ffb020"/>' + WX_SUN_RAYS,
  moon:  '<path d="M22.5 5.5a11 11 0 1 0 4 18.5A9.2 9.2 0 0 1 22.5 5.5z" fill="#dfe6f5" stroke="#9aa8bf" stroke-width="1.1"/>',
  partly:'<circle cx="12" cy="11.5" r="5" fill="#ffb020"/><g stroke="#ffb020" stroke-width="1.8" stroke-linecap="round"><path d="M12 2.5v2M3 11.5h2M5.6 5.1 7 6.5M18.4 5.1 17 6.5"/></g><g transform="translate(3 3) scale(.88)">' + WX_CLOUD + '</g>',
  partlyNight:'<path d="M16 4a7 7 0 1 0 6 10.5A5.8 5.8 0 0 1 16 4z" fill="#dfe6f5" stroke="#9aa8bf" stroke-width="1"/><g transform="translate(3 3) scale(.88)">' + WX_CLOUD + '</g>',
  cloud: WX_CLOUD,
  fog:   '<g stroke="#9aa8bf" stroke-width="2.2" stroke-linecap="round"><path d="M6 11h20M4 16h24M8 21h16M11 26h10"/></g>',
  rain:  WX_CLOUD + '<g stroke="#3b9cff" stroke-width="2" stroke-linecap="round"><path d="M11 27l-1 3M17 27l-1 3M23 27l-1 3"/></g>',
  snow:  WX_CLOUD + '<g fill="#7fb8ff"><circle cx="11" cy="28" r="1.5"/><circle cx="17" cy="28" r="1.5"/><circle cx="23" cy="28" r="1.5"/></g>',
  storm: WX_CLOUD + '<path d="M17.5 21l-4 6h3l-1.5 5 5.5-7.5h-3.2z" fill="#ffc83d" transform="translate(0 -2)"/>',
};

function wxIcon(kind) {
  const s = document.createElement("span");
  s.className = "wx-ico";
  s.innerHTML = '<svg viewBox="0 0 32 32" width="100%" height="100%" aria-hidden="true">' + (WX_ICONS[kind] || WX_ICONS.cloud) + "</svg>";
  return s;
}

// WMO weather code -> [description, icon, night icon]
function wxInfo(code, isDay) {
  const day = isDay !== 0;
  if (code === 0) return ["Clear", day ? "sun" : "moon"];
  if (code === 1) return ["Mostly clear", day ? "sun" : "moon"];
  if (code === 2) return ["Partly cloudy", day ? "partly" : "partlyNight"];
  if (code === 3) return ["Overcast", "cloud"];
  if (code === 45 || code === 48) return ["Fog", "fog"];
  if (code >= 51 && code <= 57) return ["Drizzle", "rain"];
  if (code >= 61 && code <= 67) return ["Rain", "rain"];
  if (code >= 71 && code <= 77) return ["Snow", "snow"];
  if (code >= 80 && code <= 82) return ["Showers", "rain"];
  if (code === 85 || code === 86) return ["Snow showers", "snow"];
  if (code >= 95) return ["Thunderstorm", "storm"];
  return ["—", "cloud"];
}

// ======================================================================================
// Widgets
// ======================================================================================
const Widgets = (() => {
  const locale = () => CONFIG.locale || undefined;
  const hour12 = () => store("clock.hour12", CONFIG.clock.hour12);

  // ---- Weather ---------------------------------------------------------------------
  const WX_KEY = "wx.cache.v1";
  const WX_TTL = 20 * 60 * 1000;

  async function getJSON(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    return res.json();
  }

  async function loadWeather() {
    const city = (CONFIG.weather.city || "").trim();
    const units = CONFIG.weather.units === "fahrenheit" ? "fahrenheit" : "celsius";
    const cached = store(WX_KEY, null);
    const same = cached && cached.city === city && cached.units === units;
    if (same && Date.now() - cached.t < WX_TTL) return cached;

    try {
      let place = same ? cached.place : null;
      if (!place) {
        const g = await getJSON(
          "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=" + encodeURIComponent(city)
        );
        if (!g.results || !g.results.length) throw new Error("City not found");
        const r = g.results[0];
        place = { name: r.name, lat: r.latitude, lon: r.longitude };
      }
      const f = await getJSON(
        "https://api.open-meteo.com/v1/forecast?latitude=" + place.lat + "&longitude=" + place.lon +
        "&current=temperature_2m,weather_code,is_day&hourly=temperature_2m,weather_code,is_day" +
        "&forecast_days=2&timezone=auto&temperature_unit=" + units
      );
      const data = { t: Date.now(), city, units, place, current: f.current, hourly: f.hourly };
      save(WX_KEY, data);
      return data;
    } catch (err) {
      if (same) return { ...cached, stale: true }; // better an old forecast than none
      throw err;
    }
  }

  function buildWeather() {
    const city = el("div", { class: "wx-city", text: CONFIG.weather.city || "" });
    const temp = el("div", { class: "wx-temp", text: "–°" });
    const descWrap = el("div", { class: "wx-desc" });
    const hours = el("div", { class: "wx-hours" });
    const node = el("div", { class: "widget weather", "aria-label": "Weather" },
      el("div", { class: "wx-top" }, el("div", {}, city, temp), descWrap),
      hours
    );

    let data = null;
    function paint() {
      if (!data) return;
      city.textContent = data.place.name;
      temp.textContent = Math.round(data.current.temperature_2m) + "°";
      const [text, kind] = wxInfo(data.current.weather_code, data.current.is_day);
      descWrap.replaceChildren(wxIcon(kind), el("span", { text: data.stale ? text + " (offline)" : text }));

      const h = data.hourly;
      const nowHour = data.current.time.slice(0, 13) + ":00";
      let start = h.time.findIndex((t) => t >= nowHour);
      if (start < 0) start = 0;
      hours.replaceChildren();
      for (let i = 0; i < 6 && start + i < h.time.length; i++) {
        const k = start + i;
        const hr = parseInt(h.time[k].slice(11, 13), 10);
        const label = i === 0 ? "Now"
          : new Date(2000, 0, 1, hr).toLocaleTimeString(locale(), { hour: "numeric", hour12: hour12() });
        const live = i === 0;
        const [, ik] = live
          ? wxInfo(data.current.weather_code, data.current.is_day)
          : wxInfo(h.weather_code[k], h.is_day[k]);
        hours.append(
          el("div", { class: "wx-hour" },
            el("span", { class: "wx-h", text: label }),
            wxIcon(ik),
            el("span", { class: "wx-t", text: Math.round(live ? data.current.temperature_2m : h.temperature_2m[k]) + "°" })
          )
        );
      }
    }
    loadWeather().then((d) => { data = d; paint(); }).catch(() => {
      descWrap.replaceChildren(el("span", { text: "Weather unavailable" }));
    });
    document.addEventListener("clockformat", paint);
    return node;
  }

  // ---- Calendar (month grid) -------------------------------------------------------
  function buildCalendar() {
    const month = el("div", { class: "cal-month" });
    const grid = el("div", { class: "mini-grid" });
    const node = el("button", { type: "button", class: "widget calendar", "aria-label": "Calendar — open full calendar",
      onclick: () => openCalendar() }, month, grid);
    let shown = "";

    function paint() {
      const now = new Date();
      const key = now.toDateString();
      if (key === shown) return;
      shown = key;
      const ws = CONFIG.weekStartsOn === 1 ? 1 : 0;
      month.textContent = now.toLocaleString(locale(), { month: "long" });
      grid.replaceChildren();
      for (let i = 0; i < 7; i++) {
        const d = new Date(2021, 7, 1 + ((i + ws) % 7)); // 2021-08-01 was a Sunday
        grid.append(el("span", { class: "dow", text: d.toLocaleString(locale(), { weekday: "narrow" }) }));
      }
      const y = now.getFullYear(), m = now.getMonth();
      const lead = (new Date(y, m, 1).getDay() - ws + 7) % 7;
      for (let i = 0; i < lead; i++) grid.append(el("span"));
      const days = new Date(y, m + 1, 0).getDate();
      for (let d = 1; d <= days; d++) {
        grid.append(el("span", { class: "d" + (d === now.getDate() ? " today" : ""), text: String(d) }));
      }
    }
    paint();
    setInterval(paint, 60 * 1000); // rolls over at midnight
    return node;
  }

  // ---- Analog clock ----------------------------------------------------------------
  function buildClock() {
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 120 120");
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", "Analog clock");
    const mk = (tag, attrs, text) => {
      const n = document.createElementNS(NS, tag);
      for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
      if (text != null) n.textContent = text;
      svg.append(n);
      return n;
    };
    for (let i = 0; i < 60; i++) {
      const a = (i * 6 * Math.PI) / 180, major = i % 5 === 0;
      const r1 = major ? 52 : 54.5, r2 = 57;
      mk("line", {
        x1: 60 + Math.sin(a) * r1, y1: 60 - Math.cos(a) * r1,
        x2: 60 + Math.sin(a) * r2, y2: 60 - Math.cos(a) * r2,
        class: major ? "tick major" : "tick",
      });
    }
    for (let n = 1; n <= 12; n++) {
      const a = (n * 30 * Math.PI) / 180;
      mk("text", { x: 60 + Math.sin(a) * 42, y: 60 - Math.cos(a) * 42 + 4.2, class: "num", "text-anchor": "middle" }, String(n));
    }
    const hourH = mk("line", { x1: 60, y1: 64, x2: 60, y2: 38, class: "hand hour" });
    const minH = mk("line", { x1: 60, y1: 66, x2: 60, y2: 24, class: "hand min" });
    const secH = mk("line", { x1: 60, y1: 68, x2: 60, y2: 18, class: "hand sec" });
    mk("circle", { cx: 60, cy: 60, r: 3, class: "pin" });

    const rot = (n, deg) => n.setAttribute("transform", `rotate(${deg} 60 60)`);
    function paint() {
      const d = new Date();
      const s = d.getSeconds(), m = d.getMinutes() + s / 60, h = (d.getHours() % 12) + m / 60;
      rot(hourH, h * 30); rot(minH, m * 6); rot(secH, s * 6);
    }
    paint();
    setInterval(paint, 1000);
    return el("div", { class: "widget aclock" }, svg);
  }

  // ---- Init ------------------------------------------------------------------------
  function applyLook() {
    const root = document.documentElement;
    root.dataset.widgets = store("ui.widgetStyle", CONFIG.widgets.style) === "dark" ? "dark" : "light";
    root.style.setProperty("--wall-brightness", String(store("ui.brightness", 1)));
    root.style.setProperty("--glass-a", String(store("ui.glass", root.dataset.widgets === "dark" ? 0.5 : 0.6)));
  }

  function init() {
    applyLook();
    const host = document.getElementById("widgets");
    const w = CONFIG.widgets;
    if (w.weather) host.append(buildWeather());
    if (w.calendar) host.append(buildCalendar());
    if (w.clock) host.append(buildClock());
  }

  return { init, applyLook };
})();

// ======================================================================================
// Control center — web-appropriate stand-ins for the phone's tiles
// ======================================================================================
const focusTimer = { dur: 25 * 60000, remaining: 25 * 60000, running: false, endAt: 0, timeout: null, audio: null };

function focusLeft() {
  return focusTimer.running ? Math.max(0, focusTimer.endAt - Date.now()) : focusTimer.remaining;
}
function focusFinish() {
  focusTimer.running = false;
  focusTimer.remaining = 0;
  try {
    const ctx = focusTimer.audio;
    if (ctx) [0, 0.35].forEach((t) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = 880; o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.3);
      o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.32);
    });
  } catch {}
  document.dispatchEvent(new Event("focusdone"));
}
function focusSet(running) {
  clearTimeout(focusTimer.timeout);
  if (running) {
    if (focusTimer.remaining <= 0) focusTimer.remaining = focusTimer.dur;
    focusTimer.endAt = Date.now() + focusTimer.remaining;
    focusTimer.running = true;
    try { focusTimer.audio = focusTimer.audio || new AudioContext(); focusTimer.audio.resume(); } catch {}
    focusTimer.timeout = setTimeout(focusFinish, focusTimer.remaining);
  } else {
    focusTimer.remaining = focusLeft();
    focusTimer.running = false;
  }
}

function openControlCenter() {
  Panels.toggle("control", "Control center", (body, ctx) => {
    const root = document.documentElement;
    const circle = (name, label, onclick, big) =>
      el("button", { type: "button", class: "circle" + (big ? " lg" : ""), "aria-label": label, title: label, onclick }, icon(name));

    // Network
    const netIcon = el("span", { class: "net-ico" });
    const netSub = el("span", { class: "tile-sub" });
    const netTitle = el("span", { class: "tile-title" });
    const net = el("div", { class: "widget tile net" }, netIcon, el("div", { class: "tile-text" }, netTitle, netSub));
    const paintNet = () => {
      const on = navigator.onLine;
      const c = navigator.connection;
      netIcon.replaceChildren(icon(on ? "wifi" : "wifiOff"));
      netIcon.classList.toggle("on", on);
      netTitle.textContent = on ? "Online" : "Offline";
      netSub.textContent = on ? (c && c.effectiveType ? c.effectiveType.toUpperCase() : "Connected") : "No connection";
    };
    paintNet();
    window.addEventListener("online", paintNet);
    window.addEventListener("offline", paintNet);

    // Focus timer (the "media" tile)
    const fTitle = el("div", { class: "tile-title", text: "Focus" });
    const fTime = el("div", { class: "focus-time" });
    const playBtn = el("button", { type: "button", class: "circle", "aria-label": "Start or pause" });
    const fmt = (ms) => {
      const s = Math.ceil(ms / 1000);
      return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    };
    const paintFocus = () => {
      const left = focusLeft();
      fTime.textContent = fmt(left);
      fTitle.textContent = focusTimer.running ? "Focusing" : left === 0 ? "Done" : "Focus";
      playBtn.replaceChildren(icon(focusTimer.running ? "pause" : "play"));
    };
    playBtn.addEventListener("click", () => { focusSet(!focusTimer.running); paintFocus(); });
    const focusTile = el("div", { class: "widget tile focus" },
      fTitle, fTime,
      el("div", { class: "focus-controls" },
        circle("reset", "Reset", () => {
          clearTimeout(focusTimer.timeout); focusTimer.running = false; focusTimer.remaining = focusTimer.dur; paintFocus();
        }),
        playBtn,
        el("button", { type: "button", class: "circle plus", "aria-label": "Add 5 minutes", title: "+5 min", text: "+5", onclick: () => {
          if (focusTimer.dur >= 90 * 60000) return;
          focusTimer.dur += 5 * 60000;
          if (focusTimer.running) { focusTimer.endAt += 5 * 60000; clearTimeout(focusTimer.timeout); focusTimer.timeout = setTimeout(focusFinish, focusLeft()); }
          else focusTimer.remaining += 5 * 60000;
          paintFocus();
        } })
      )
    );
    paintFocus();
    const fInterval = setInterval(paintFocus, 250);
    document.addEventListener("focusdone", paintFocus);

    // Quick toggles
    const pauseBtn = circle("pause", "Pause wallpaper rotation", () => {
      const p = Wallpaper.togglePause();
      pauseBtn.classList.toggle("active", p);
    });
    pauseBtn.classList.toggle("active", Wallpaper.paused);
    const styleBtn = circle("swatch", "Switch light/dark widgets", () => {
      const next = root.dataset.widgets === "dark" ? "light" : "dark";
      save("ui.widgetStyle", next);
      localStorage.removeItem("ui.glass");
      Widgets.applyLook();
      glassSlider.value = String(parseFloat(getComputedStyle(root).getPropertyValue("--glass-a")));
      setFill(glassSlider);
    });
    const quick = el("div", { class: "circles" }, circle("refresh", "Next wallpaper", () => Wallpaper.next()), pauseBtn, styleBtn);

    // Sliders
    function setFill(input) {
      const min = +input.min, max = +input.max;
      input.style.setProperty("--p", ((input.value - min) / (max - min)) * 100 + "%");
    }
    function slider(label, name, min, max, value, onInput) {
      const input = el("input", { type: "range", min: String(min), max: String(max), step: "0.01", "aria-label": label });
      input.value = String(value);
      setFill(input);
      input.addEventListener("input", () => { setFill(input); onInput(+input.value); });
      return [el("div", { class: "widget slider" }, el("span", { class: "tile-title", text: label }), input), input];
    }
    const [displayEl] = slider("Display", "sun", 0.35, 1, store("ui.brightness", 1), (v) => {
      root.style.setProperty("--wall-brightness", String(v)); save("ui.brightness", v);
    });
    const [glassEl, glassSlider] = slider("Glass", "glass", 0.2, 0.9, parseFloat(getComputedStyle(root).getPropertyValue("--glass-a")) || 0.6, (v) => {
      root.style.setProperty("--glass-a", String(v)); save("ui.glass", v);
    });

    // Shortcuts to the other tools
    const find = (id) => TOOLS.find((t) => t.id === id);
    const launch = (id, label, ic) => circle(ic, label, () => find(id).run(), true);

    ctx.onClose = () => {
      clearInterval(fInterval);
      document.removeEventListener("focusdone", paintFocus);
      window.removeEventListener("online", paintNet);
      window.removeEventListener("offline", paintNet);
    };
    body.append(
      el("div", { class: "cc-grid" }, net, focusTile, quick),
      displayEl,
      glassEl,
      el("div", { class: "cc-row" },
        launch("calculator", "Calculator", "calculator"),
        launch("stopwatch", "Stopwatch", "timer"),
        launch("notes", "New note", "note"),
        launch("todo", "To-do", "todo"))
    );
  }, { bare: true });
}
